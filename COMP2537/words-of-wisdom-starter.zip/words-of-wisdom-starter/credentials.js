// const DB_URL = "mongodb://localhost:27017"
const DB_URL = ""

module.exports = { DB_URL};