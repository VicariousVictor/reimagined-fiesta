// const DB_URL = "mongodb://localhost:27017"
const DB_URL = 'mongodb+srv://root:root@cluster0-citpo.mongodb.net/test?retryWrites=true&w=majority'
module.exports = { DB_URL};